var myName = "Andrew";

function sayNAme(){
	var secret = "watchandcode";
	console.log(myName);
}

sayNAme();
console.log(secret);

//if youre inside of a function, you can look out and see data, but the opposite isn't true.  If you're outisde, you can't look in.
