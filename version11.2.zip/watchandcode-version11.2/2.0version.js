function sayHiTo(person){
	console.log("hi", person);
}
//person = "Gordon"
sayHiTo("Gordon");


// function makeSandwchWith(filling){
// 	Get one slice of bread;
// 	Add _____;
// 	Put a slice of bread on top;
// }
// makeTurkeySandwish();

// makeSandwchWith ______
// Get one slice of bread;
// 	Add _____;
// 	Put a slice of bread on top;
	
	
// 	makeSandwchWith(ham);
// console.log()